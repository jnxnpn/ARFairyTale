# @author: Zeyi Liu
# @time: 07/14/2019
# @event: THE hack
# @description: a web scrawler using scrapy framework to obtain and process data
#               from a story collection website

from scrapy import cmdline
cmdline.execute('scrapy crawl stories_spider'.split())
