# -*- coding: utf-8 -*-
import scrapy
import re
from stories.items import StoriesItem
from jieba import analyse

class StoriesSpiderSpider(scrapy.Spider):
    # 爬虫的名字
    name = 'stories_spider'
    # 允许的域名
    # allowed_domains = ['movie.douban.com']
    # 入口url，扔到调度器里面
    start_urls = ['http://gs.jzb.com/jd/a2336/']

    # clear the txt file first before each web scrawl
    f = open("matrix.txt", "w")
    f.write('')
    f.close()

    def parse(self, response):


        # 将小故事网站上的数据抓取下来，将故事title和url存在dict里
        stories_list = response.xpath("//div[@class='main_List']//ul[@class='tm10']//li").extract()
        stories_url = response.xpath("//div[@class='main_List']//ul[@class='tm10']//li/a/@href").extract()
        list_to_url = dict()
        for i in range(len(stories_list)):
            list_to_url[stories_list[i]] = stories_url[i]

        # 数据的抓取部分
        for link in stories_url:
            yield scrapy.Request("http://gs.jzb.com" + link, callback=self.look_inside)

        try:
            next_link_1 = response.xpath("//div//h2//a[2]/@href").extract_first()
            next_link_2 = response.xpath("//div//h2//a[3]/@href").extract_first()
        except:
            return

        yield scrapy.Request(self.start_urls[0] + next_link_1, callback=self.parse)
        yield scrapy.Request(self.start_urls[0] + next_link_2, callback=self.parse)


    def look_inside(self, response):

        stories_item = StoriesItem()
        title_and_length = response.xpath("//html//title//text()").extract_first()

        args = title_and_length.split("_")
        title_and_length = args[0]

        stories_item["title"] = title_and_length[:len(title_and_length) - 4]
        try:
            stories_item["length"] = int(title_and_length[len(title_and_length) - 4:-1])

        except:
            # eliminate on noisy data
            return

        stories_item["content"] = re.sub(r'</?\w+[^>]*>','', response.xpath("//div[@class = 'art_Con tm10']").extract_first())


        row = self.convert_to_value(stories_item)
        temp = ','.join(row)

        # write to a txt file
        f = open("matrix.txt", "a")
        f.write('['+temp+']')
        f.close()




    def convert_to_value(self,stories_item):

        list = self.extract_keyword(stories_item["content"])
        result = []
        #8 keyword properties
        for i in range(8):
            result.append(str(hash(list[i])))


        # length -> 1 min, 2min, 3min, 4min
        # 1 length properties

        if stories_item["length"] == 100: result.append('1')
        elif stories_item["length"] == 200: result.append('2')
        elif stories_item["length"] == 300: result.append('3')
        elif stories_item["length"] == 400: result.append('4')
        elif stories_item["length"] == 500: result.append('5')
        else:
            result.append('3')

        return result


    def extract_keyword(self, text):

        #An NLP package to extract keywords from text

        word_list = []

        # 引入TF-IDF关键词抽取接口
        tfidf = analyse.extract_tags

        # 基于TF-IDF算法进行关键词抽取
        keywords = tfidf(text)
        # 输出抽取出的关键词
        for keyword in keywords:
            word_list.append(keyword)

        return word_list































