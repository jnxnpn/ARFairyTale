Page({
  data: {
    items: [
      {name: 'a', value: '温馨'},
      {name: 'b', value: '奇幻', checked: 'true'},
      {name: 'c', value: '励志'},
      {name: 'd', value: '冒险'},
      {name: 'e', value: '经典'},
      {name: 'f', value: '浪漫'},
    ]
  },
  checkboxChange: function(e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value)
  }
})
