import numpy as np
import matplotlib.pyplot as plt
import string



###此处为读入database
#读入
f1=open('database.txt','r')
cNames = f1.readlines()
f1.close()

#split
cNames
c2=''.join(cNames)
c2.split(" ")

#创建新数组
#C_X对应 X_test; C_y对应 y_test
C_X=[]
C_y=[]

for i in range(len(c2)):
    if(i%4==0):
        C_y.append(c2[i])
    else:
        C_X.append(c2[i])




###现在的代码
#这些代码只是现在演示用

#_test
raw_data_X_train = [[3.393533211, 2.331273381,2.00],
                    [3.110073483, 1.781539638,23.22],
                    [1.343808831, 3.368360954,36.8360954],
                    [3.582294042, 4.679179110,3.68360954],
                    [2.280362439, 2.866990263,122.1],
                    [7.423436942, 4.696522875,23.2],
                    [5.745051997, 3.533989803,22.5],
                    [9.172168622, 2.511101045,90.2],
                    [7.792783481, 3.424088941,20.3],
                    [7.939820817, 0.791637231,28.2],
                    [71.939820817, 2.791637231,90.1]
                    ]
raw_data_y_train = [2, 2, 2, 0, 0, 1, 1, 1, 1, 1,3]

X_train = np.array(raw_data_X_train)
y_train = np.array(raw_data_y_train)


#_train
raw_data_X_test = [[3.393533211, 2.331273381,2.00],
                   [3.110073483, 1.781539638,23.22],
                   [1.343808831, 3.3660954,36.8360954],
                   [3.5894042, 4.679110,3.68360954],
                   [12.2803639, 2.866990263,122.1],
                   [7.42342, 4.696575,23.2],
                   [6.745051997, 3.5339803,22.5],
                   [9.172168622, 2.511101045,90.2],
                   [7.792783481, 3.424088941,20.3],
                   [7.9398217, 0.7937231,58.2],
                   [11.93920817, 2.7917231,90.1]
                   ]
raw_data_y_test = [2, 2, 2, 1, 0, 1, 3, 2, 1, 1,3]

X_test = np.array(raw_data_X_test)
y_test = np.array(raw_data_y_test)


#x设为要predict的y项目
x = np.array([82.093607318, 3.365731514,12.23]).reshape(1, -1)

##V#展示数据结束



#KNN 算法
from KNN_alg.kNN import KNNClassifier
#from sklearn.neighbors import KNeighborsClassifier
kNN_classifier = KNNClassifier(k=3)
#拟合
kNN_classifier.fit(X_train, y_train)


#预测
y1=kNN_classifier.predict(x)[0]
print("KNN算法得到结论为：")
print(y1)

#准确度
y1_predict = kNN_classifier.predict(X_test)
acu1=sum(y1_predict == y_test) / len(y_test)
print("KNN算法准确度为：")
print(acu1)



#决策树算法
from sklearn.tree import DecisionTreeClassifier
#拟合
dt_clf = DecisionTreeClassifier(max_depth=2, criterion="entropy", random_state=42)
dt_clf.fit(X_train, y_train)

#预测
y2=dt_clf.predict(x)[0]
print("决策树算法得到结论为：")
print(y2)

#准确度
acu2=dt_clf.score(X_test, y_test)
print("决策树算法准确度为：")
print(acu2)


#逻辑回归算法
from logistic_alg.LogisticRegression import LogisticRegression
log_reg = LogisticRegression()
#拟合
log_reg.fit(X_train, y_train)

#预测
y3=log_reg.predict(x)[0]
print("逻辑算法得到结论为：")
print(y3)

#准确度
acu3=log_reg.score(X_test, y_test)
print("逻辑回归算法准确度为：")
print(acu3)



#集成学习
results=[y1,y2,y3]

#确认是否有重复
def findDuplicate(lst):
    for i in range (len(lst)):
        for j in range (0,i):
            if(lst[i]==lst[j]):
                return 1
    return 0

dupResult=findDuplicate(results)

#如果有重复
if (dupResult==1):
    thisResult=max(set(results), key=results.count)
    print("集成算法得到结论为：")
    print(thisResult)


#如果没有重复
if (dupResult==0):
    print("集成算法得到结论为："+y3)
    print(y3)
